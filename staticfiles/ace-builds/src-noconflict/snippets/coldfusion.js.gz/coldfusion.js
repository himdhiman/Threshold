ace.define("ace/snippets/coldfusion",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "coldfusion";

});
